const User = require("../model/userModel.js");
const bcrypt = require("bcryptjs");
var jwt = require("jsonwebtoken");

const register = async (req, res) => {
  const { email, password } = req.body;
  try {
    const userdata = await User.findOne({ email }).select("-password");
    if (userdata) {
      res.status(400).json({ message: "User already exists", success: false });
      return;
    }
    const salt = bcrypt.genSaltSync(10);
    const hashedPassword = bcrypt.hashSync(password, salt);

    const user = new User({
      email,
      password: hashedPassword,
    });

    user.save();
    const data = {
      user: {
        id: user._id,
      },
    };
    const authtoken = jwt.sign(data, process.env.JWT_SECRET);

    res
      .status(200)
      .json({
        message: "User registered successful",
        success: true,
        token: authtoken,
      });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      message: "Internal server error during registration",
      success: false,
    });
  }
};

const login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const userData = await User.find({ email });
    if (!userData) {
      res.status(400).json({ message: "Invalid Credientials", success: false });
      return;
    }

    const matchPassword = bcrypt.compareSync(password, userData[0].password);
    if (!matchPassword) {
      res.status(400).json({ message: "Invalid Credientials", success: false });
      return;
    }
    const data = {
      user: {
        id: userData._id,
      },
    };
    const authtoken = jwt.sign(data, process.env.JWT_SECRET);

    res
      .status(200)
      .json({ message: "Login successfull", success: true, token: authtoken });
  } catch (error) {
    console.log(error);
    res
      .status(500)
      .json({ message: "Internal server error during Login", success: false });
  }
};

const updateProfile = async (req, res) => {
  const { username, email, address } = req.body;
  try {
    const newData = {};
    if (username) {
      newData.username = username;
    }
    if (email) {
      newData.email = email;
    }
    if (address) {
      newData.address = address;
    }

    const user = await User.findByIdAndUpdate(
      req.user.id,
      { $set: newData },
      { new: true }
    ).select("-password");

    if(!user){
      res.status(404).json({message:"User not found",success: false});
      return;
    }
    res
      .status(200)
      .json({ message: "updated successfully", success: true, user });

  } catch (error) {
    res.status(500).json({ message: "Internal server error", success: false });
  }
};

const profiles = async (req, res) => {
  try {
    const users = await User.find().select("-password");
    if (!users) {
      res.status(400).json({ message: "No users found", success: false });
    }
    res
      .status(200)
      .json({ message: "Users Extracted successfully", success: true, users });
  } catch (error) {
    res.status(500).json({ message: "Internal Server Error", success: false });
  }
};

module.exports = {
  register,
  login,
  updateProfile,
  profiles,
};
