const express = require("express");
const userController = require("../controller/userController.js");
const fetchuser = require("../middleware/fetchuser.js");
const router = express();

router.get("/", async (req, res) => {
  res.send("hello chahat");
});
router.post("/api/v1/register", userController.register);
router.post("/api/v1/login", userController.login);
router.post("/api/v1/updateProfile", fetchuser, userController.updateProfile);
router.get("/api/v1/users", userController.profiles);

module.exports = router;
