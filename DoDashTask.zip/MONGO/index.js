const express = require("express"); 
const connectDB = require("./config/db.js");
const router = require("./Routes/routes.js");
const app = express(); 

require("dotenv").config();
app.use(express.json());

connectDB();


app.use("/",router);

app.listen(process.env.PORT, function (err) {
  if (err) console.log(err);
  console.log("Server listening on PORT", process.env.PORT);
});
